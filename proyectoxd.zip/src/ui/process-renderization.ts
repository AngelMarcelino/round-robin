import { Process } from "../models/process";

function innerContainerStyles() {
  return `
  position: absolute;
  top: 0px;
  border: 1px solid #000;
  background-color: red;
  transform: rotate(
  180deg
  );
  bottom: 0;
  left: 0;
  right: 0;
  `;
}

function outterContainerStyles() {
  return `
    width: 100px;
    height: 201px;
    border: 1px solid #000;
    position: relative;
  `;
}

export function renderProcess(process: Process) {
  let outterContainer = document.createElement("div");
  outterContainer.className = "process";
  outterContainer.setAttribute("style", outterContainerStyles());
  let innerContainer = document.createElement("div");
  innerContainer.className = "inner-process";
  innerContainer.setAttribute("style", innerContainerStyles());
  outterContainer.appendChild(innerContainer);
  return outterContainer;
}
