// ola k ase
// hakiandome o k ase? >.<

import { Process, ProcessState } from "./models/process";
import { renderProcess } from "./ui/process-renderization";

const startBtn = document.getElementById("startBtnId");
const quantumTimeInput = document.getElementById("quantum-value");
const processContainer = document.getElementById("process-container");

startBtn.addEventListener("click", () => {
  let quantumTime: string = (<HTMLInputElement>quantumTimeInput).value;
  start(+quantumTime);
});

function createNewProcess(time: number, name: string): Process {
  return {
    completionTime: time,
    processName: name,
    remainingTime: 0,
    state: ProcessState.WAITING,
  };
}

let intervalId: any;
function start(quantumTime: number) {
  intervalId = setInterval(() => {
    processContainer.appendChild(renderProcess(createNewProcess(10, "hola")));
  }, 1000);
}
