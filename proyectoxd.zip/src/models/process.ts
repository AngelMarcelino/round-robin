export enum ProcessState {
  COMPLETED = 'completed',
  WAITING = 'waiting',
  BLOCKED = 'blocked',
}

export interface Process {
  completionTime: number;
  remainingTime: number;
  processName: string;
  state: ProcessState;
}
